# ZIP Password BruteForcer
## Zip File Password Cracking with Using Password List !

<h5>Language: Python</h5>
<h5>Coder: Sir.4m1R</h5>

-----------------

<h5>The404Hacking</h5>
<h5>Digital Security ReSearch Group</h5>

-----------------
# Need?
You need a Password List to use this Script !

Sample Password List: [Show](https://github.com/The404Hacking/ZIP-Password-BruteForcer/blob/master/pass.txt)

-----------------
# Consider ... 
This Script can only Crack files with the `*.zip` Formatand Can not Crack files in .rar format.

Sample .Zip File: [Show](https://github.com/The404Hacking/ZIP-Password-BruteForcer/blob/master/File.zip)

`Password: 123321`

-----------------
# ScreenShot:

Start ScreenShot:

![ZIP-Password-BruteForcer ScreenShot](Start-Screenshot.png?raw=true "ZIP-Password-BruteForcer")


Password Found ScreenShot:

![Password Found ScreenShot](Password-Found-Screenshot.png?raw=true "Password Found ScreenShot")

-----------------
# Usage:

**Linux:**
```
> git clone https://github.com/The404Hacking/ZIP-Password-BruteForcer
> cd ZIP-Password-BruteForcer
> python ZIP-Password-BruteForcer.py
```

**Windows:**
```
Download from https://github.com/The404Hacking/ZIP-Password-BruteForcer/archive/master.zip
ZIP-Password-BruteForcer-master.zip
Extract files.
cd ZIP-Password-BruteForcer
python ZIP-Password-BruteForcer.py
```
-----------------
# Download and Clone
> Download: Click [Here](https://github.com/The404Hacking/ZIP-Password-BruteForcer/archive/master.zip)

> Clone: git clone [https://github.com/The404Hacking/ZIP-Password-BruteForcer.git](https://github.com/The404Hacking/ZIP-Password-BruteForcer.git)

# The404Hacking | Digital UnderGround Team
[The404Hacking](https://T.me/The404Hacking)

# Follow us !
[The404Hacking](https://T.me/The404Hacking) - [The404Cracking](https://T.me/The404Cracking)

[Instagram](https://instagram.com/The404Hacking) - [GitHub](https://github.com/The404Hacking)

[YouTube](http://yon.ir/youtube404) - [Aparat](http://www.aparat.com/The404Hacking)

[Blog](http://the404hacking.blogsky.com) - [Email](mailto:The404Hacking.Team@Gmail.Com)
